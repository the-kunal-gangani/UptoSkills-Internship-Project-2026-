import 'dart:async';

import 'package:flutter/material.dart';

class EduEraWelcomeScreen extends StatefulWidget {
  const EduEraWelcomeScreen({super.key});

  @override
  State<EduEraWelcomeScreen> createState() => _EduEraWelcomeScreenState();
}

class _EduEraWelcomeScreenState extends State<EduEraWelcomeScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 2), () {});
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Welcome to',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.w500)),
              SizedBox(height: 10),
              Text('EduEra',
                  style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    );
  }
}

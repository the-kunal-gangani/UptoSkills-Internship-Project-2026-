TinySteps + EduEra changes

New files:
- lib/views/auth/screens/app_selection_screen.dart
- lib/views/auth/screens/eduera_welcome_screen.dart

Router changes:
- lib/core/router/app_router_changes.txt

IMPORTANT: Do not replace your existing app_router.dart with app_router_changes.txt.
Apply the listed changes to your existing router so all existing TinySteps routes remain unchanged.
